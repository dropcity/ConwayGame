#' @title Matrix equality check
#'
#' @description Checks if two matrices are equal: are both of them matrices and have the same dimension
#' 
#' @author Leila Feddoul
#' 
#' @param x the first Matrix.
#' @param y the second Matrix.
#'
#' @return true if the two matrices are equal otherwise false  .
#'
#' @examples
#'\dontrun{
#' matequal(A,B)
#' }
#'
matequal <-
function(x, y)
  is.matrix(x) && is.matrix(y) && dim(x) == dim(y) && all(x == y)
