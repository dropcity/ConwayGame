#' @title Visualise the game of life
#' 
#' @description Plots the cell matrix as a field of squares. Black cells are alive, colored cells are alive and recognized as patterns.
#' 
#' @author Anastasia Aftakhova
#' 
#' @import plotrix
#' @param env environment containing the cell matrix and the color mapping
#' @param plotname name of the plotted image
#' 
#' @examples 
#'\dontrun{
#' env <- new.env()
#' env$M <- array(c(0,1,0,1,0,1,0,1,0), c(3,3))
#' env$colorMapping <- 
#'}
#' 
visualise <-
function(env, plotname) {
  cellcol <- array(, dim=dim(env$M))
  for (i in 1:dim(env$colorMapping)[1]) {
    cellcol[which(env$M == (env$colorMapping)$num[i])] <- (env$colorMapping)$col[i]
  }
  color2D.matplot(env$M, cellcolors = cellcol, border=NA, main=plotname)
}
