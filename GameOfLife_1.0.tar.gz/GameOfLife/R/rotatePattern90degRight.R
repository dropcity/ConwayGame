#' @title Rotate pattern
#' 
#' @description Rotates the given pattern matrix 90 degrees to the right
#'
#' @author Anastasia Aftakhova
#'
#' @param pattern input 2D matrix
#'
#' @return a rotated input matrix
#' 
#' @examples
#'\dontrun{
#' pattern <- array(c(0,5,0,5,0,1,0,2,0), c(3,3))
#' rotatePattern90degRight(pattern)
#' }
#'
rotatePattern90degRight <-
function(pattern) {
  rotatedPattern <- t(pattern[nrow(pattern):1,])
  return(rotatedPattern)
}
