#' @title Run Conway's game of life
#' 
#' @description 
#' Main game loop. Manages creation os start matrix and its updating, as well as pattern detection 
#' and visualization of matrix within each iteration.
#' 
#' @export
#' 
#' @author Anastasia Aftakhova, Leila Feddoul, Selina Müller
#'
#' @param iter_number number of iterations of the game (life cycles) 
#' @param matrix_or_size containing either a start matrix for the game of life or the size the start matrix should have
#' @param save_path path where matrices are saved as images
#' @param paths list of file paths, each containing patterns as a .txt-file
#'
#' @example 
#'\dontrun{
#' starteSpiel(iter_number = 10, matrix_or_size = 100, save_path = "C:/Users/me/Documents/ConwayPatterns", paths = c("C:/Users/me/Documents/ConwayPatterns/glider.txt", "C:/Users/me/Documents/ConwayPatterns/still.txt"))
#' }
#'
starteSpiel <-
function(iter_number, matrix_or_size, save_path, paths) {
  gameenv <- new.env()
  
  if (is.matrix(matrix_or_size)) {
    gameenv$M <- matrix_or_size
  } else {
    gameenv$M <- createMatrix(matrix_or_size)  
  }
  
  gameenv$creatures <- getAllPatterns(paths)
  gameenv$colorMapping <- createColorMapping(gameenv)
  
  for (i in c(1:iter_number)) { # check if for-Loop correct
    M = detectPatterns(gameenv)
    visualise(gameenv, sprintf('Iteration %d', i));
    #Sys.sleep(1);
    
    # save M if needed
    if (i%%1 == 0) {
      save(save_path, i)
    }
    
    # setzte M zurück (= entfärben)
    decolorM(gameenv);
    
    # compute next live iteration
    computeAll(gameenv)
  }
}
