#' @title implement the Game of live Rules
#'
#' @description decides if the matrix central cell schould live or die depending of the number and the state of it neighbours
#' 
#' @author Leila Feddoul
#'
#' @param N  3x3 matrix of neighbours for an element with given indices.
#'
#' @return 1 if the central cell of the matrix should live or 0 when it should die.
#'
#' @examples
#'\dontrun{
#' N = matrix( c(0, 0, 0, 0, 1, 0, 0, 0, 0), nrow=3, ncol=3) 
#' computeIsAlive(N)
#' }
#'
computeIsAlive <-
function(N) {
  # return 0(Tot) oder 1(Lebend)
  alive<-0
  for ( i in 1:3 )
  {
    for(j in 1:3)
    {
      if(N[i,j]== 1) alive<-alive+1
      
    }
  }
  
  if(N[2,2]==1)
  {
    alive <- alive-1
    if(alive<2 || alive>3) {return(0)}
    else
    {
      if(alive==2 || alive==3) return(1)
    }
  }
  if(N[2,2]==0)
  {
    if(alive==3) return(1)
  }
  return(0)
}
