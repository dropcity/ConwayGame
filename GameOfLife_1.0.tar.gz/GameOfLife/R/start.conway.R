#' @title Run Conway's game of life
#' 
#' @description 
#' Main game loop. Manages creation os start matrix and its updating, as well as pattern detection 
#' and visualization of matrix within each iteration.
#' 
#' @export
#' 
#' @author Anastasia Aftakhova, Leila Feddoul, Selina Müller
#'
#' @param iter_number number of iterations of the game (life cycles) 
#'
#' @example 
#'\dontrun{
#' newgame <- conway(iter_number = 10, matrix_or_size = 100, save_path = "ConwayPatterns", paths = c("ConwayPatterns/still.txt"))
#' start(newgame)
#' }
#' 
start.conway <-
function (game) {
  for (i in c(1:game$maxiter)) { # check if for-Loop correct
    game$iter <- i
    detectPatterns(game$env)
    visualise(game$env, sprintf('Iteration %d', i));
    #Sys.sleep(1);
    
    # save M if needed
    if (i%%1 == 0) {
      save(game$savepath, i)
    }
    
    if (i%%1 == 0) {
      summary(game)
    }
    
    # setzte M zurück (= entfärben)
    decolorM(game$env);
    
    # compute next live iteration
    computeAll(game$env)
  }
}
