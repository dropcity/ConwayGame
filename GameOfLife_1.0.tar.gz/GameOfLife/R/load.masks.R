#' @title Load masks that are saved in a txt-file
#' 
#' @description 
#' Reads a .txt-file containing matrix patterns that ought to be recognized
#' and saves all patterns in a list of matrices. The object "creature" 
#' is created wich contains said list and its assigned colour. 
#' 
#' @author Selina Müller
#'
#' @param path file path containing the pattern as a .txt-file
#'
#' @return an object containing all patterns and assigned colour of given file path
#' 
#' @example 
#'\dontrun{
#' load.masks("C:/Users/me/Documents/ConwayPatterns/glider.txt")
#' }
#' 
load.masks <-
function(path) {
  creature <- {}
  patterns <- {}
  c <- as.integer(scan(file=path, skip =1, nlines = 1, what = "numerical", quiet = TRUE))
  r <- as.integer(scan(file=path, skip =2, nlines = 1, what = "numerical", quiet = TRUE))
  dat = read.table(file = path, skip = 3, header = FALSE, comment.char = "")
  con <- file(path, "r")
  line.number <- 1
  while(TRUE){
    line <- readLines(con, n=1)
    if(length(line) == 0){
      break
    }
    if(line.number > 3){
      pattern <- matrix(scan(text = line, what = "numeric", quiet = TRUE), nrow=r, ncol = c, byrow = TRUE)
      class(pattern) <- "numeric"
      patterns <- append(patterns, list(pattern))
    }
    line.number <- line.number + 1
  }
  close(con)
  colour <- scan(file=path, nlines =1, comment.char = "", what="character", quiet = TRUE)
  creature$color <- colour
  creature$patterns <- patterns
  return(creature)
}
