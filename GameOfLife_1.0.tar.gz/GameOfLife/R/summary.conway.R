#' @title Summary
#' 
#' @description 
#' Generic function. Prints out the current state of the game.
#' 
#' @author Anastasia Aftakhova
#'
#' @param game the game object instance
#'
#' @example
#'\dontrun{ 
#' newgame <- conway(iter_number = 10, matrix_or_size = 100, save_path = "ConwayPatterns", paths = c("ConwayPatterns/still.txt"))
#' summary(newgame)
#' }
#
summary.conway <-
function(game) {
  dim1 <- dim(game$env$M)[1]
  dim2 <- dim(game$env$M)[2]
  aliveNumber <- sum(game$env$M)
  cat(sprintf("\nConway's Game Summary:\n"))
  cat(sprintf("   Iteration:   %d\n", game$iter))
  total <- dim1*dim2
  cat(sprintf("   Spielfeld:   %d x %d (L x B)\n", dim1, dim2))
  cat(sprintf("   Lebend:      %d   ~  %.2f%% \n", aliveNumber, aliveNumber/total*100))
  deadNumber <- dim1*dim2 - aliveNumber
  cat(sprintf("   Tot:         %d   ~  %.2f%% \n", deadNumber, deadNumber/total*100))
}
