#' @title Generate a random matrix
#'
#' @description Creates a random nxn matrix of ones and zeros.
#' 
#' @author Leila Feddoul
#' 
#' @export
#' 
#' @param matrix_size  the size of the matrix.
#'
#' @return the generated matrix .
#'
#' @examples
#'\dontrun{
#' createMatrix(3)
#' }
#'
createMatrix <-
function(matrix_size) {
  matrix = replicate(matrix_size,sample(c(0,1),matrix_size,replace = TRUE ,c(0.5,0.5)))
  return(matrix)
}
