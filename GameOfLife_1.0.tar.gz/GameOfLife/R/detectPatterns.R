#' @title Detect life patterns
#' 
#' @description Recognizes known patterns for a specific iteration of a game.
#' 
#' @author Anastasia Aftakhova
#' 
#' @param env Environment with specified game matrix and
#' creature object list (= patterns or figures to recognize)
#'
#' @example 
#'\dontrun{
#' env <- new.env()
#' env$M <- array(c(0,5,0,5,0,1,0,2,0), c(3,3))
#' decolorM(env)
#' }
#' 
detectPatterns <-
function(env) {
  for(i in env$creatures){
    col = (env$colorMapping)$num[which((env$colorMapping)$col == i$color)];
    for(p in i$patterns){
      findPatternMatch(env, p, col);
    }
  }
}
