#' @title Save game of life matrix
#' 
#' @description Saves the current cell matrix plot image into the input path directory.
#'
#' @author Anastasia Aftakhova
#' 
#' @param save_path full path string of a directory to save the image into
#' @param iter_id number of current game iteration
#' 
#' @examples
#'\dontrun{ 
#' save('/game_snapshots', 5)
#' }
#' 
save <-
function(save_path, iter_id) {
  dev.copy(png, sprintf('%s/cgofl_%s.png', save_path, iter_id), width=500, height=500, units="px")
  dev.off()
}
