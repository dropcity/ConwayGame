#' @title Remove coloring from matrix
#' 
#' @description Removes the coloring of patterns in the matrix. Replaces color numbers in the cell matrix with the default alive value.
#'
#' @author Anastasia Aftakhova
#'
#' @param col Environment containing the cell matrix
#' 
#' @examples
#' \dontrun{
#' env <- new.env()
#' env$M <- array(c(0,5,0,5,0,1,0,2,0), c(3,3))
#' decolorM(env)
#' }
#' 
decolorM <-
function(env) {
  env$M[which(env$M >0)] = 1;
}
