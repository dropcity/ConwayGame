#' @title Conway's Game of Life
#' 
#' @description 
#' Object-oriented implementaion of a Conway's Game of Life.
#' 
#' @author Anastasia Aftakhova, Leila Feddoul, Selina Müller
#' 
#' @export
#'
#' @param iter_number number of iterations of the game (life cycles) 
#' @param matrix_or_size containing either a start matrix for the game of life or the size the start matrix should have
#' @param save_path path where matrices are saved as images
#' @param paths list of file paths, each containing patterns as a .txt-file
#'
#' @example
#' \dontrun{ 
#' newgame <- conway(iter_number = 10, matrix_or_size = 100, save_path = "C:/Users/me/Documents/ConwayPatterns", paths = c("C:/Users/me/Documents/ConwayPatterns/glider.txt", "C:/Users/me/Documents/ConwayPatterns/still.txt"))
#'}
#'
conway <-
function(iter_number, matrix_or_size, save_path, paths) {
  library(plotrix)
  gameenv <- new.env()
  if (is.matrix(matrix_or_size)) {
    gameenv$M <- matrix_or_size
  } else {
    gameenv$M <- createMatrix(matrix_or_size)  
  }
  
  gameenv$creatures <- getAllPatterns(paths)
  gameenv$colorMapping <- createColorMapping(gameenv)
  
  game <- list(iter=0, maxiter = iter_number, savepath = save_path, env = gameenv)
  class(game) <- "conway"
  return(game)
}
