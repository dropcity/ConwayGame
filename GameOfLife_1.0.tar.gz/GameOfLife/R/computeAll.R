#' @title Update matrix
#' 
#' @description 
#' Determines for each cell in Matrix M, if it survives or dies 
#' and saves updated matrix in R
#' 
#' @author Selina Müller
#'
#' @param env Environment containing game matrix: M and dataframe: colorMapping
#' 
#' @example
#'\dontrun{ 
#' R <- computeAll(matrix( c(0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0), nrow=15, ncol=15))
#' }
#'
computeAll <-
function(env) {
  R <- matrix(data=0, ncol=ncol(env$M), nrow=nrow(env$M))
  
  ncM <- ncol(env$M)
  nrM <- nrow(env$M)
  
  for (i in 1:nrM){
    for(j in 1:ncM){
      N<-getNeighbours(env,i,j)
      R[i,j] <- computeIsAlive2(N)
    }
  }
  env$M <- R
}
