#' @title Find out pattern matching   
#'
#' @description Searches for given pattern in the cell matrix and colors it if found ( Alternative implementation for findPatternMatch function)
#' 
#' @author Leila Feddoul
#' 
#' @param env Environment containing the cell matrix an color mapping
#' @param mask 2D matrix of a pattern to be recognized 
#' @param col a color number which is set for alive cells of a found pattern
#' 
#' @examples 
#'\dontrun{
#' env <- new.env()
#' env$M <- array(c(0,1,0,1,0,1,0,1,0), c(3,3))
#' pattern <- matrix(c(0,1,1,0), ncol=2)
#' findPatternMatch_2(env, pattern, 5)
#' }
#' 
findPatternMatch_2 <-
function(env, mask, col)
{
  maskSize<-dim(mask)
  nrM<-nrow(env$M)
  ncM<-ncol(env$M)
  for(i in 1:(nrM-maskSize[1]))
  {
    for(j in 1:(ncM-maskSize[1]))
    {
      N<-env$M[i:(i+(maskSize[1]-1)),j:(j+(maskSize[1]-1))]
      if(matequal(mask,N))
      {
        N[which(N == 1)] <- col
        env$M[i:(i+(maskSize[1]-1)),j:(j+(maskSize[1]-1))]<-N
      }
    }
  }
}
