#' @title Check if a cell survives
#' 
#' @description Alternative implementation of computeIsAlive function. Decides if a given matrix cell remains alive/dead or not.
#'
#' @author Anastasia Aftakhova
#' 
#' @param N 3x3 neighbours matrix for one cell 
#'
#' @return binary cell value; 1 if alive; 0 if not
#' 
#' @examples
#'\dontrun{
#' N = matrix( c(0, 1, 1, 1, 1, 0, 0, 0, 0), nrow=3, ncol=3) 
#' computeIsAlive2(N)
#' }
#'
computeIsAlive2 <-
function(N) {
  allElem <- sum(N)
  if (N[2,2] == 1) {
    if (allElem < 5 && allElem > 2) {
      return(1)
    } else {
      return(0)
    }
  } else {
    if (allElem == 3) {
      return(1)
    } else {
      return(0)
    }
  }
}
