#' @title Create color mapping
#' 
#' @description  Automatically creates a color mapping for the environment with the given creature list.
#'
#' @author Anastasia Aftakhova
#'
#' @param env Environment with creature object list
#' 
#' @examples
#'\dontrun{
#' paths <- c('patterns/mynewpattern.txt') 
#' env <- new.env()
#' env$creatures <- getAllPatterns(paths)
#' createColorMapping(env)
#' }
#' 
createColorMapping <-
function(env) {
  numbers <- c(0,1)
  colors <- c('white', 'black')
  
  for (i in env$creatures) {
    if (sum(colors == i$color) == 0) {
      numbers <- union(numbers, numbers[length(numbers)]+1)
      colors <- union(colors, i$color)    
    }
  }
  env$colorMapping = data.frame(num=numbers, col=colors, stringsAsFactors = FALSE)
}
