#' @title Create object that holds all patterns as lists
#' 
#' @description 
#' Iterates through list of file paths containing all patterns and saving them in an object called creatures.
#'
#' @author Selina Müller
#'
#' @param paths list of file paths, each containing patterns as a .txt-file
#'
#' @return a vector containing objects holding all patterns and assigned colour of each file in paths
#' 
#' @example
#' \dontrun{
#' getAllPatterns("C:/Users/me/Documents/ConwayPatterns/glider.txt", "C:/Users/me/Documents/ConwayPatterns/still.txt")
#' }
#' 
getAllPatterns <-
function(paths) {
  # für alle paths creatures auslesen und als vector von objekten zurückgeben
  creatures <- list()
  for (i in 1:length(paths)) {
    creatures[[length(creatures) +1]] <- addRotatedPatterns(load.masks(paths[i]))
  }
  return(creatures);
}
