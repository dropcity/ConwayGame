#' @title Find a pattern
#' 
#' @description Searches for given pattern in the cell matrix and colors it if found.
#' 
#' @author Anastasia Aftakhova
#' 
#' @param env Environment containing the cell matrix an color mapping
#' @param pattern 2D matrix of a pattern to be recognized 
#' @param colNum a color number which is set for alive cells of a found pattern
#' 
#' @examples
#'\dontrun{
#' env <- new.env()
#' env$M <- array(c(0,1,0,1,0,1,0,1,0), c(3,3))
#' pattern <- matrix(c(0,1,1,0), ncol=2)
#' findPatternMatch(env, pattern, 5)
#' }
#' 
findPatternMatch <-
function(env, pattern, colNum) {
  location = matrix(, ncol=2)
  for (i in 1:(nrow(env$M)-nrow(pattern)-1)) {
    for (j in 1:(ncol(env$M)-ncol(pattern)-1)) {
      subM = env$M[i:(i-1+nrow(pattern)), j:(j-1+ncol(pattern))];
      if (identical(subM,pattern)) {
        subM[which(subM == 1)] = colNum
        env$M[i:(i-1+nrow(pattern)), j:(j-1+ncol(pattern))] = subM;
      }
    }
  }
}
