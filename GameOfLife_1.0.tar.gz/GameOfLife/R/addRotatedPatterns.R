#' @title Add rotated patterns
#' 
#' @description Adjusts creature patterns list with the rotated patterns in order to detect all rotations of patterns.
#'
#' @author Anastasia Aftakhova
#'
#' @param creature a list object containing color and a list 
#' of 2D matrices with patterns for this "creature"
#'
#' @return modified creature object
#' 
#' @examples 
#'\dontrun{
#' creature <- load.masks("patterns/glider.txt")
#' addRotatedPatterns(creature)
#' }
#' 
addRotatedPatterns <-
function(creature) {
  patterns <- creature$patterns
  for (p in creature$patterns) {
    pat <- p
    for( i in 1:3) {
      pat <- rotatePattern90degRight(pat)
      patternExists <- FALSE
      for (existingPat in patterns) {
        if (identical(pat, existingPat)) {
          patternExists <- TRUE
          break()
        }
      }
      if (!patternExists) {
        patterns <- append(patterns, list(pat))  
      }
    }
  }
  creature$patterns <- patterns
  return(creature)
}
