#' @title get neighbours of a cell
#' 
#' @description Creates a 3x3 neighbour matrix for a given element
#'
#' @author Selina Müller
#'
#' @param env Environment containing game matrix: M and dataframe: colorMapping
#' @param i row index of matrix element
#' @param j column index of matrix element
#'
#' @return 3x3 matrix of neighbours for an element with given indices
#' 
#' @examples
#'\dontrun{
#' M <- matrix( c(0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0), nrow=15, ncol=15) 
#' N <- getNeighbours(M, 5,8)
#' }
#' 
getNeighbours <-
function(env, i,j) {
  
  ncM <- ncol(env$M)
  N <- matrix(nrow = 3, ncol = 3);
  
  if(i == 1 || i == ncM || j == 1 || j == ncM ){
    
    a <- i-1
    if(a == 0) a <-ncM
    b <- i+1
    if(b == ncM+1) b <-1
    c <- j-1
    if(c == 0)c <-ncM
    d <- j+1
    if(d==ncM+1) d <- 1
    
    N[1,1] <- env$M[a,c]
    N[2,1] <- env$M[i,c]
    N[3,1] <- env$M[b,c]
    N[1,2] <- env$M[a,j]
    N[2,2] <- env$M[i,j]
    N[3,2] <- env$M[b,j]
    N[1,3] <- env$M[a,d]
    N[2,3] <- env$M[i,d]
    N[3,3] <- env$M[b,d]
    
  }else{
    
    e<-i-1
    f<-i+1
    g<-j-1
    h<-j+1
    N<-env$M[e:f,g:h]
  }
  
  return(N)
}
